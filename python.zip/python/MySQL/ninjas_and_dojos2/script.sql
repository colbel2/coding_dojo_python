SELECT * FROM dojos_and_ninjas.ninjas;
INSERT INTO ninjas (dojo_id,first_name,last_name,age)
VALUES(1,'Todd','Enders',26),
(1,'Speros','Misirkokis',28),
(1,'Donovan','An',27),
(1,'Phil','Krull',31);
SELECT * FROM dojos_and_ninjas.ninjas;