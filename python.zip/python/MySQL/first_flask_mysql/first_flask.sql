SELECT * FROM friends;
INSERT INTO friends (first_name, last_name, occupation) 
VALUES('Jon', 'Blake', 'Dolphin'),
('Jake', 'Miller', 'Bartender')
,('Sam', 'Spencer', 'Trucker');
SELECT * FROM friends;