SELECT * FROM users_schema.users;
INSERT INTO users (first_name, last_name, email)
VALUES('Bob','Marley','bob@marley.com'),
('Hulk','Hogan','hulk@hogan.com'),
('Jimmy','Hendrix','jimmy@hendrix.com'),
('Dwayne','Johnson','dwayne@johnson.com'),
('Elvis','Presley','elvis@presley.com');
SELECT * FROM users_schema.users;
