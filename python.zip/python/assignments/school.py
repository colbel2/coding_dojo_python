# x=7//2+10%2**4

# print(x)

# def calc_value(val):

#     val+=3

#     return val*4



# x=2

# print(calc_value(x))

x=2

y=3

while x+y<10:

    if x==5:

        pass

    x+=1

    print(x)