count = 0
while count <= 5:
    print("looping - ", count)
    count += 1

