function swapPairs(arr) {
    for (let i = 0; i < arr.lenght; i+=2) {
        if (arr.length == )
        
        let temp = arr[i];
        arr[i] = arr[i +1]
        arr[i +1] = temp;
    }
}
